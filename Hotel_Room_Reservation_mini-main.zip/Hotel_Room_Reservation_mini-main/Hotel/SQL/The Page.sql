create database sum;

use sum;

create table sum (a int, v varchar(50));

insert into sum values (1,'helo'),(2,'belo');

select * from sum;


create database jbeans;
use jbeans;


select * from a_mate;
select * from a_room;

drop   table a_room;
drop   table a_mate;

